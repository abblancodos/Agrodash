<!-- src/lib/components/processes/NodeCanvas.svelte -->
<script lang="ts">
  import { onMount } from 'svelte';

  function defaultParams(type: string): Record<string, any> {
    const d: Record<string, any> = {
      postgres_sensor: { sensors: [] },
      kalman:          { Q: 1e-5, R: 1e-3, P0: 1.0, convergence_threshold: 5e-4, warmup_samples: 10 },
      moving_avg:      { window_n: 10, warmup_samples: 10 },
      ewma:            { alpha: 0.1, warmup_samples: 10 },
      lowpass:         { tau_seconds: 120, warmup_samples: 10 },
      passthrough:     {},
      concat:          {},
      weighted_mean:   { weights: [] },
      mahalanobis:     { target: [], threshold_act: 2.5, threshold_deact: 1.0, use_kalman_P: true },
      hysteresis:      { reduction: { type: 'mean' }, low: 0.08, high: 0.085, action_below_low: 'on', action_above_high: 'off' },
      sprt:            { mu_H0: 0.0, mu_H1: 1.0, sigma: 0.1, alpha: 0.05, beta: 0.05, reduction: { type: 'mean' }, reset_on_action: true },
      actuator: {
        label: '',
        decision: { method: 'hysteresis', reduction: { type: 'mean' }, low: 0.08, high: 0.085, action_below: 'on', action_above: 'off' },
        output:   { protocol: 'mqtt', connection: 'shared', topic: '', payload_on: 'on,1', payload_off: 'off,1' },
        stages:   null,
        coherence: null,
      },
      mqtt_actuator:   { connection: 'shared', topic: '', payload_on: 'on', payload_off: 'off' },
      http_actuator:   { connection: 'shared', path_on: '/on', path_off: '/off' },
      logger:          { tag: '' },
      select:          { indices: [] },
      linear_scale:    { a: 1.0, b: 0.0 },
    };
    return d[type] ?? {};
  }
  import PipelineBlock from './PipelineBlock.svelte';
  import WatchdogBlock from './WatchdogBlock.svelte';
  import type { ProcessConfig } from '$lib/stores/process';

  let {
    pipeline,
    availableSensors,
    canEdit,
    onchange,
  }: {
    pipeline: any;
    availableSensors: { id: string; label: string }[];
    canEdit: boolean;
    onchange: () => void;
  } = $props();

  // ── State ─────────────────────────────────────────────────────────────────
  let canvasEl = $state<HTMLDivElement | null>(null);
  let svgEl    = $state<SVGSVGElement | null>(null);

  // Node positions — keyed by node id
  let positions = $state<Record<string, { x: number; y: number }>>({});

  // Block element refs — for edge calculation
  let blockRefs: Record<string, HTMLDivElement> = {};
  // Watchdog port element refs — for accurate edge calculation
  let wdPortEls = $state<Record<string, Record<string, HTMLElement | undefined>>>({});
  // Track block dimensions for edge calculation
  let blockSizes = $state<Record<string, { w: number; h: number }>>({});;

  // Update block size after render
  function measureBlock(nodeId: string, el: HTMLDivElement | null) {
    if (!el) return;
    blockRefs[nodeId] = el;
    // Use offsetWidth/Height which work correctly with position:absolute
    const w = el.offsetWidth  || 180;
    const h = el.offsetHeight || 36;
    if (blockSizes[nodeId]?.w !== w || blockSizes[nodeId]?.h !== h) {
      blockSizes = { ...blockSizes, [nodeId]: { w, h } };
    }
  }
  let renderTick = $state(0); // increment to force edge re-render after DOM updates

  // Dragging state
  let dragging = $state<{ nodeId: string; startX: number; startY: number; origX: number; origY: number } | null>(null);

  // Panning state
  let panning = $state<{ startX: number; startY: number; origPanX: number; origPanY: number } | null>(null);
  let panX = $state(0);
  let panY = $state(0);

  // Connecting state — drawing an edge
  let connecting = $state<{ fromId: string; fromPort: 'output'; fromPortName?: string; x: number; y: number } | null>(null);
  let mouseX = $state(0);
  let mouseY = $state(0);

  // Expanded blocks
  let expanded = $state<Set<string>>(new Set());

  // ── Init positions from saved node_positions or auto-layout ───────────────
  onMount(() => {
    initPositions();
  });

  function initPositions() {
    const saved = pipeline.node_positions ?? {};
    const nodes = pipeline.nodes ?? [];
    const newPos: Record<string, { x: number; y: number }> = {};

    nodes.forEach((n: any, i: number) => {
      newPos[n.id] = saved[n.id] ?? { x: 60 + i * 260, y: 100 };
    });
    positions = newPos;
    // Delay edge render until DOM has painted the blocks
    setTimeout(() => {
      renderTick++;
      // Measure all blocks after DOM paints
      for (const nodeId of Object.keys(positions)) {
        measureBlock(nodeId, blockRefs[nodeId]);
      }
    }, 60);
  }

  // When pipeline changes (tab switch), reinit
  $effect(() => {
    const _id = pipeline.id; // track pipeline id
    initPositions();
    expanded = new Set();
  });

  // ── Node metadata ──────────────────────────────────────────────────────────
  const NODE_COLORS: Record<string, string> = {
    postgres_sensor:  '#4a90d9',
    kalman: '#7c6fcd', moving_avg: '#7c6fcd', ewma: '#7c6fcd',
    lowpass: '#7c6fcd', passthrough: '#8a9bb0',
    concat: '#e8a838', weighted_mean: '#e8a838',
    mahalanobis: '#e07b54', hysteresis: '#e07b54', sprt: '#e07b54',
    actuator: '#3da85a',
    mqtt_actuator: '#3da85a', http_actuator: '#3da85a',
    mqtt_subscriber: '#c084fc', watchdog: '#c084fc',
    logger: '#8a9bb0', select: '#8a9bb0', linear_scale: '#8a9bb0',
  };

  const NODE_CATEGORY: Record<string, string> = {
    postgres_sensor:  'fuente',
    kalman: 'filtro', moving_avg: 'filtro', ewma: 'filtro',
    lowpass: 'filtro', passthrough: 'filtro',
    concat: 'combinador', weighted_mean: 'combinador',
    mahalanobis: 'decisor', hysteresis: 'decisor', sprt: 'decisor',
    actuator: 'actuador',
    mqtt_actuator: 'actuador', http_actuator: 'actuador',
    mqtt_subscriber: 'watchdog', watchdog: 'watchdog',
    logger: 'util', select: 'util', linear_scale: 'util',
  };

  // ── Resize state ───────────────────────────────────────────────────────────
  let resizing = $state<{
    nodeId: string;
    startX: number; startY: number;
    origW: number;  origH: number;
  } | null>(null);

  // Block sizes (user-resized or measured)
  let userSizes = $state<Record<string, { w: number; h: number }>>({});

  function startResize(e: MouseEvent, nodeId: string) {
    e.preventDefault();
    e.stopPropagation();
    const size = blockSizes[nodeId] ?? { w: 220, h: 100 };
    resizing = {
      nodeId,
      startX: e.clientX, startY: e.clientY,
      origW: size.w, origH: size.h,
    };
  }

  // ── Dragging ───────────────────────────────────────────────────────────────
  function startDrag(e: MouseEvent, nodeId: string) {
    if ((e.target as HTMLElement).closest('.port, button, input, select, textarea, .resize-handle')) return;
    e.preventDefault();
    e.stopPropagation(); // prevent canvas pan from firing
    if (!canEdit) return;
    // Leer posición visual desde el DOM para que funcione aunque el nodo
    // no haya sido movido antes (positions[nodeId] podría ser undefined o stale)
    const el = blockRefs[nodeId];
    const canvasRect = canvasEl?.getBoundingClientRect();
    let origX: number, origY: number;
    if (el && canvasRect) {
      const rect = el.getBoundingClientRect();
      origX = (rect.left - canvasRect.left - panX);
      origY = (rect.top  - canvasRect.top  - panY);
    } else {
      const pos = positions[nodeId] ?? { x: 0, y: 0 };
      origX = pos.x; origY = pos.y;
    }
    dragging = { nodeId, startX: e.clientX, startY: e.clientY, origX, origY };
  }

  // Canvas panning
  function startPan(e: MouseEvent) {
    if (dragging || connecting) return;
    if ((e.target as HTMLElement).closest('.block, .resize-handle')) return;
    e.preventDefault();
    panning = { startX: e.clientX, startY: e.clientY, origPanX: panX, origPanY: panY };
  }

  function onMouseMove(e: MouseEvent) {
    if (canvasEl) {
      const rect = canvasEl.getBoundingClientRect();
      mouseX = e.clientX - rect.left - panX;
      mouseY = e.clientY - rect.top  - panY;
    }
    if (resizing) {
      const dx = e.clientX - resizing.startX;
      const dy = e.clientY - resizing.startY;
      const w  = Math.max(200, resizing.origW + dx);
      const h  = Math.max(120, resizing.origH + dy);
      userSizes = { ...userSizes, [resizing.nodeId]: { w, h } };
      blockSizes = { ...blockSizes, [resizing.nodeId]: { w, h } };
      return;
    }
    if (dragging) {
      const dx = e.clientX - dragging.startX;
      const dy = e.clientY - dragging.startY;
      positions = {
        ...positions,
        [dragging.nodeId]: {
          x: Math.max(0, dragging.origX + dx),
          y: Math.max(0, dragging.origY + dy),
        }
      };
      return;
    }
    if (panning) {
      panX = panning.origPanX + (e.clientX - panning.startX);
      panY = panning.origPanY + (e.clientY - panning.startY);
    }
  }

  function onMouseUp() {
    if (resizing) { resizing = null; return; }
    if (dragging) {
      pipeline.node_positions = { ...pipeline.node_positions, ...positions };
      dragging = null;
      onchange();
    }
    if (panning) { panning = null; }
    connecting = null;
  }

  // ── Connecting ports ───────────────────────────────────────────────────────
  function startConnect(e: MouseEvent, fromId: string, fromPortName?: string) {
    if (!canEdit) return;
    e.stopPropagation();
    if (!canvasEl) return;
    const rect = canvasEl.getBoundingClientRect();
    connecting = {
      fromId,
      fromPort: 'output',
      fromPortName,
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  }

  function endConnect(e: MouseEvent, toId: string, toPortName?: string) {
    if (!connecting || connecting.fromId === toId) { connecting = null; return; }
    e.stopPropagation();
    // Add edge if not duplicate
    const edges = pipeline.edges ?? [];
    const exists = edges.some((ed: any) => ed.from === connecting!.fromId && ed.to === toId);
    if (!exists && connecting.fromId !== toId) {
      pipeline.edges = [...edges, {
        id: `${connecting.fromId}-${toId}`,
        from:      connecting.fromId,
        to:        toId,
        from_port: connecting.fromPortName ?? null,
        to_port:   toPortName ?? null,
      }];
      setTimeout(() => { renderTick++; }, 20);
      onchange();
      syncWatchdogActuatorIds();
    }
    connecting = null;
  }

  // Drop from BlockPicker
  function onDrop(e: DragEvent) {
    e.preventDefault();
    const type = e.dataTransfer?.getData('text/plain');
    if (!type || !canvasEl) return;
    const rect = canvasEl.getBoundingClientRect();
    // Drop position in canvas coords (accounting for pan)
    const x = e.clientX - rect.left - panX;
    const y = e.clientY - rect.top  - panY;

    const id  = `${type}_${Date.now()}`;
    const nodes = pipeline.nodes ?? [];
    pipeline.nodes = [...nodes, { id, type, ...defaultParams(type) }];
    if (!pipeline.node_positions) pipeline.node_positions = {};
    pipeline.node_positions[id] = { x: Math.max(0, x - 90), y: Math.max(0, y - 20) };
    positions = { ...positions, [id]: pipeline.node_positions[id] };
    setTimeout(() => { renderTick++; }, 50);
    onchange();
  }

  function removeEdge(edgeId: string) {
    pipeline.edges = (pipeline.edges ?? []).filter((e: any) => e.id !== edgeId);
    onchange();
    syncWatchdogActuatorIds();
  }

  function removeNode(nodeId: string) {
    pipeline.nodes = (pipeline.nodes ?? []).filter((n: any) => n.id !== nodeId);
    pipeline.edges = (pipeline.edges ?? []).filter((e: any) => e.from !== nodeId && e.to !== nodeId);
    if (pipeline.node_positions) delete pipeline.node_positions[nodeId];
    const newPos = { ...positions };
    delete newPos[nodeId];
    positions = newPos;
    onchange();
  }

  function toggleExpand(nodeId: string) {
    const next = new Set(expanded);
    if (next.has(nodeId)) next.delete(nodeId);
    else next.add(nodeId);
    expanded = next;
  }

  // ── Edge SVG paths ─────────────────────────────────────────────────────────
  // Port names per node type
  const PORT_NAMES: Record<string, { inputs: string[]; outputs: string[] }> = {
    postgres_sensor:  { inputs: [],                                    outputs: ['sig_out'] },
    kalman:           { inputs: ['sig_in'],                            outputs: ['sig_out'] },
    moving_avg:       { inputs: ['sig_in'],                            outputs: ['sig_out'] },
    ewma:             { inputs: ['sig_in'],                            outputs: ['sig_out'] },
    lowpass:          { inputs: ['sig_in'],                            outputs: ['sig_out'] },
    passthrough:      { inputs: ['sig_in'],                            outputs: ['sig_out'] },
    concat:           { inputs: ['sig_in×N'],                          outputs: ['sig_out'] },
    weighted_mean:    { inputs: ['sig_in×N'],                          outputs: ['sig_out'] },
    mahalanobis:      { inputs: ['sig_in'],                            outputs: ['act_out'] },
    hysteresis:       { inputs: ['sig_in'],                            outputs: ['act_out'] },
    sprt:             { inputs: ['sig_in'],                            outputs: ['act_out'] },
    actuator:         { inputs: ['sig_in'],                            outputs: ['act_out'] },
    mqtt_actuator:    { inputs: ['act_in'],                            outputs: [] },
    http_actuator:    { inputs: ['act_in'],                            outputs: [] },
    mqtt_subscriber:  { inputs: [],                                    outputs: ['mqtt_ret_out'] },
    watchdog:         { inputs: ['act_in', 'mqtt_ret_in', 'sig_in'],   outputs: ['act_out'] },
    logger:           { inputs: ['sig_in'],                            outputs: ['sig_out'] },
    select:           { inputs: ['sig_in'],                            outputs: ['sig_out'] },
    linear_scale:     { inputs: ['sig_in'],                            outputs: ['sig_out'] },
  };

  function portName(nodeType: string, port: 'input' | 'output', index = 0): string {
    const names = PORT_NAMES[nodeType];
    if (!names) return port === 'input' ? 'in' : 'out';
    const list = port === 'input' ? names.inputs : names.outputs;
    return list[index] ?? (port === 'input' ? 'in' : 'out');
  }

  // Short label for a node — used in edge labels
  function nodeLabel(nodeId: string): string {
    const node = (pipeline.nodes ?? []).find((n: any) => n.id === nodeId);
    if (!node) return nodeId.slice(-6);
    const type = (node.type as string).replace(/_/g, ' ');
    // Use tag/topic/label if available, else type
    const detail = node.tag || node.topic || node.label || '';
    return detail ? `${type} · ${detail}` : type;
  }

  // Derive actuator_id for watchdog nodes from their output edge
  function watchdogActuatorId(nodeId: string): string {
    const edge = (pipeline.edges ?? []).find((e: any) => e.from === nodeId);
    return edge?.to ?? '';
  }

  // Sync actuator_id for all watchdog nodes based on edges
  function syncWatchdogActuatorIds() {
    let changed = false;
    for (const node of (pipeline.nodes ?? [])) {
      if (node.type === 'watchdog') {
        const derived = watchdogActuatorId(node.id);
        if (derived && node.actuator_id !== derived) {
          node.actuator_id = derived;
          changed = true;
        }
      }
    }
    if (changed) onchange();
  }

  function getPortCenter(nodeId: string, port: 'input' | 'output', portNameArg?: string): { x: number; y: number } | null {
    const node = (pipeline.nodes ?? []).find((n: any) => n.id === nodeId);

    // Watchdog: calculate port positions geometrically like normal nodes
    // Inputs are spaced evenly on the left, output centered on the right
    if (node?.type === 'watchdog') {
      const pos  = positions[nodeId];
      const size = blockSizes[nodeId];
      if (!pos) return null;
      const w = size?.w ?? 220;
      const h = size?.h ?? 90;
      const cx = pos.x + panX;
      const cy = pos.y + panY;

      if (port === 'output') {
        return { x: cx + w + 6, y: cy + h / 2 };
      }
      // Inputs: act_in, mqtt_ret_in, sig_in — evenly spaced
      const INPUTS = ['act_in', 'mqtt_ret_in', 'sig_in'];
      const idx = INPUTS.indexOf(portNameArg ?? 'act_in');
      const n = INPUTS.length;
      const spacing = h / (n + 1);
      return { x: cx - 6, y: cy + spacing * (idx + 1) };
    }

    const pos  = positions[nodeId];
    const size = blockSizes[nodeId];
    if (!pos) return null;
    const w = size?.w ?? 180;
    const h = size?.h ?? 36;
    // Canvas-local coordinates (including pan offset)
    const cx = pos.x + panX;
    const cy = pos.y + panY + h / 2;
    return {
      x: port === 'input'  ? cx - 6        : cx + w + 6,
      y: cy,
    };
  }

  function cubicPath(x1: number, y1: number, x2: number, y2: number): string {
    const cx = (x1 + x2) / 2;
    return `M ${x1} ${y1} C ${cx} ${y1}, ${cx} ${y2}, ${x2} ${y2}`;
  }
</script>

<!-- svelte-ignore a11y_no_static_element_interactions -->
<div
  class="canvas"
  bind:this={canvasEl}
  onmousedown={startPan}
  onmousemove={onMouseMove}
  onmouseup={onMouseUp}
  onmouseleave={onMouseUp}
  ondragover={(e) => { e.preventDefault(); if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy'; }}
  ondrop={onDrop}
  style="cursor:{panning ? 'grabbing' : dragging ? 'grabbing' : 'default'}"
>

  <!-- SVG layer for edges -->
  <svg class="edge-svg" bind:this={svgEl}>
    {#each (pipeline.edges ?? []) as edge (edge.id)}
      {@const p1 = getPortCenter(edge.from, 'output', edge.from_port)}
      {@const p2 = getPortCenter(edge.to, 'input', edge.to_port)}
      {#if p1 && p2}
        <!-- Edge line -->
        <path
          d={cubicPath(p1.x, p1.y, p2.x, p2.y)}
          stroke="var(--text-muted)"
          stroke-width="2.5"
          fill="none"
          opacity="0.7"
        />
        <!-- Arrow at target -->
        <polygon
          points="{p2.x},{p2.y} {p2.x - 8},{p2.y - 4} {p2.x - 8},{p2.y + 4}"
          fill="var(--text-muted)"
          opacity="0.7"
        />
        <!-- Edge label — from→to -->
        {@const mx = (p1.x + p2.x) / 2}
        {@const my = (p1.y + p2.y) / 2}
        {@const fromLabel = nodeLabel(edge.from)}
        {@const toLabel   = nodeLabel(edge.to)}
        <rect
          x={mx - 54} y={my - 9}
          width="108" height="16"
          rx="4"
          fill="var(--bg-elevated)"
          stroke="var(--border-subtle)"
          stroke-width="0.5"
          opacity="0.92"
          pointer-events="none"
        />
        <text
          x={mx} y={my + 3}
          text-anchor="middle"
          font-size="8"
          font-family="DM Mono, monospace"
          fill="var(--text-muted)"
          pointer-events="none"
        >{fromLabel} → {toLabel}</text>

        <!-- Edge delete button -->
        {#if canEdit}
          <circle
            cx={mx + 60} cy={my}
            r="7"
            fill="var(--bg-elevated)"
            stroke="var(--border-default)"
            stroke-width="1"
            style="cursor:pointer"
            role="button"
            tabindex="0"
            onclick={() => removeEdge(edge.id)}
            onkeydown={(e) => e.key === 'Enter' && removeEdge(edge.id)}
          />
          <text
            x={mx + 60} y={my + 4}
            text-anchor="middle"
            font-size="10"
            fill="var(--text-muted)"
            style="cursor:pointer;pointer-events:none"
          >✕</text>
        {/if}
      {/if}
    {/each}

    <!-- In-progress connection line -->
    {#if connecting}
      {@const p1 = getPortCenter(connecting.fromId, 'output')}
      {#if p1}
        <path
          d={cubicPath(p1.x, p1.y, mouseX, mouseY)}
          stroke="var(--nc, #4a90d9)"
          stroke-width="2"
          stroke-dasharray="6 3"
          fill="none"
          pointer-events="none"
          opacity="0.8"
        />
      {/if}
    {/if}
  </svg>

  <!-- Blocks — translated by pan offset -->
  <div class="blocks-layer" style="transform:translate({panX}px,{panY}px)">
  {#each (pipeline.nodes ?? []) as node (node.id)}
    {@const pos = positions[node.id] ?? { x: 60, y: 100 }}
    {@const color = NODE_COLORS[node.type] ?? '#8a9bb0'}
    {@const category = NODE_CATEGORY[node.type] ?? ''}
    {@const isExpanded = expanded.has(node.id)}
    {@const usize = userSizes[node.id]}

    <!-- svelte-ignore a11y_no_static_element_interactions -->
    {#if node.type === 'watchdog'}
      <!-- Watchdog: special layout with named multi-port block -->
      <div
        class="block block-watchdog"
        style="left:{pos.x}px; top:{pos.y}px; --nc:{color}{usize && isExpanded ? `; width:${usize.w}px; height:${usize.h}px` : ''}"
        bind:this={blockRefs[node.id]}
        onmouseenter={() => measureBlock(node.id, blockRefs[node.id])}
      >
        <WatchdogBlock
          {node}
          {color}
          {isExpanded}
          {canEdit}
          onexpand={() => toggleExpand(node.id)}
          onremove={() => removeNode(node.id)}
          onchange={onchange}
          onstartdrag={(e: MouseEvent) => startDrag(e, node.id)}
          onresize={isExpanded && canEdit ? (e: MouseEvent) => startResize(e, node.id) : undefined}
          onconnectstart={(e, nid, pname) => startConnect(e, nid, pname)}
          onconnectend={(e, nid, pname) => endConnect(e, nid, pname)}
          portEls={wdPortEls[node.id] ?? {}}
          onPortEls={(els: Record<string, HTMLElement | undefined>) => { wdPortEls[node.id] = els; }}
        />
      </div>
    {:else}
      <div
        class="block"
        class:expanded={isExpanded}
        style="left:{pos.x}px; top:{pos.y}px; --nc:{color}{usize && isExpanded ? `; width:${usize.w}px; height:${usize.h}px` : ''}"
        bind:this={blockRefs[node.id]}
        onmouseenter={() => measureBlock(node.id, blockRefs[node.id])}
      >
        <!-- Input ports -->
        {#if (PORT_NAMES[node.type]?.inputs ?? []).length > 0}
          <div class="port-column port-column-input">
            {#each (PORT_NAMES[node.type]?.inputs ?? []) as pname, pi (pi)}
              <!-- svelte-ignore a11y_no_static_element_interactions -->
              <div
                class="port port-input"
                title={pname}
                onmouseup={(e) => endConnect(e, node.id, pname)}
              ></div>
            {/each}
          </div>
        {:else}
          <div class="port-column port-column-input port-column-empty"></div>
        {/if}

        <!-- Block content -->
        <PipelineBlock
          {node}
          {color}
          {category}
          {isExpanded}
          {availableSensors}
          {canEdit}
          inputPorts={PORT_NAMES[node.type]?.inputs ?? []}
          outputPorts={PORT_NAMES[node.type]?.outputs ?? []}
          onexpand={() => toggleExpand(node.id)}
          onremove={() => removeNode(node.id)}
          onchange={onchange}
          onstartdrag={(e: MouseEvent) => startDrag(e, node.id)}
          onresize={isExpanded && canEdit ? (e: MouseEvent) => startResize(e, node.id) : undefined}
        />

        <!-- Output port -->
        {#if (PORT_NAMES[node.type]?.outputs ?? []).length > 0}
          <div class="port-column port-column-output">
            {#each (PORT_NAMES[node.type]?.outputs ?? []) as pname, pi (pi)}
              <!-- svelte-ignore a11y_no_static_element_interactions -->
              <div
                class="port port-output"
                title={pname}
                onmousedown={(e) => startConnect(e, node.id, pname)}
              ></div>
            {/each}
          </div>
        {:else}
          <div class="port-column port-column-output port-column-empty"></div>
        {/if}
      </div>
    {/if}
  {/each}

  </div><!-- end blocks-layer -->

{#if (pipeline.nodes ?? []).length === 0}
    <div class="empty-hint">
      Usá el panel izquierdo para agregar bloques al pipeline
    </div>
  {/if}
</div>

<style>
  .canvas {
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background-image: radial-gradient(var(--border-subtle) 1px, transparent 1px);
    background-size: 24px 24px;
    cursor: default;
  }

  .edge-svg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    overflow: visible;
  }
  .edge-svg circle { pointer-events: all; }

  .block {
    position: absolute;
    display: flex;
    align-items: center;
    gap: 0;
    cursor: grab;
    user-select: none;
    filter: drop-shadow(0 2px 8px rgba(0,0,0,0.08));
    transition: filter .15s;
  }
  .block:active { cursor: grabbing; filter: drop-shadow(0 4px 16px rgba(0,0,0,0.14)); }
  .block.expanded { z-index: 10; display: flex; flex-direction: column; min-width: 260px; }
  .block-watchdog { position: absolute; }
  .block.expanded :global(.block-inner) { flex: 1; max-width: none; width: 100%; height: 100%; }

  .port-column {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-shrink: 0;
  }
  .port-column-empty { width: 12px; }

  .port {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: var(--bg-surface);
    border: 2px solid var(--nc, #8a9bb0);
    flex-shrink: 0;
    z-index: 2;
    transition: transform .12s, background .12s;
  }
  .port-input  { cursor: crosshair; }
  .port-output { cursor: crosshair; }
  .port:hover  { transform: scale(1.4); background: var(--nc, #8a9bb0); }

  .empty-hint {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: var(--text-muted);
    font-size: calc(13px * var(--font-scale));
    font-family: 'DM Mono', monospace;
    pointer-events: none;
  }
</style>