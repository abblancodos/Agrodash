// api/src/ws.rs
//
// WebSocket hub para comunicación bidireccional API ↔ frontend.
//
// Arquitectura:
//   - Un broadcast::Sender<WsEvent> por process_id, guardado en WsBroadcast.
//   - El agente publica estado vía POST /agent-state → post_agent_state() llama
//     a WsBroadcast::publish(). Todos los WS conectados a ese proceso lo reciben.
//   - El frontend puede enviar comandos por el WS (mismo protocolo que el
//     endpoint POST /command). La API los procesa en el mismo handler.
//   - Sin polling, sin SSE que llene la memoria.
//
// Mensajes servidor → cliente (JSON):
//   { "type": "pipeline_state",  "pipeline_id": "...", "state": {...} }
//   { "type": "process_status",  "status": "running", "last_seen_at": "..." }
//   { "type": "mqtt_ack",        "pipeline_id": "...", "actuator_id": "...", "msg": "CONCENTRADOR:..." }
//   { "type": "log",             "level": "info", "source": "...", "message": "..." }
//   { "type": "error",           "message": "..." }
//   { "type": "pong" }
//
// Mensajes cliente → servidor (JSON):
//   { "type": "ping" }
//   { "type": "command", "cmd": "Override", "action": "on", "pipeline_id": "...", "actuator_id": "..." }
//   { "type": "command", "cmd": "ClearOverride", ... }
//   (cualquier AgentCommand envuelto en { "type": "command", ...campos })

use std::collections::HashMap;
use std::sync::Arc;

use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::extract::{Path, State};
use axum::response::IntoResponse;
use futures_util::{SinkExt, StreamExt};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tokio::sync::{broadcast, RwLock};
use tracing::{debug, info, warn};
use uuid::Uuid;

use crate::AppState;

// ── Capacidad del canal de broadcast por proceso ──────────────────────────────
// 64 mensajes en cola — suficiente para ráfagas de estado sin desperdiciar memoria.
// Si un cliente va muy lento y se queda atrás, recibirá RecvError::Lagged y
// el handler lo desconectará limpiamente.
const BROADCAST_CAPACITY: usize = 64;

// ── WsEvent: lo que se emite en el broadcast ─────────────────────────────────

#[derive(Debug, Clone, Serialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum WsEvent {
    PipelineState {
        pipeline_id: String,
        state: Value,
    },
    ProcessStatus {
        status: String,
        last_seen_at: Option<String>,
        error_message: Option<String>,
    },
    MqttAck {
        pipeline_id: String,
        actuator_id: String,
        /// JSON string con el payload completo del evento de stage:
        /// { stage_index, stage_name, status, message, action, payload, ... }
        msg: String,
    },
    Log {
        level: String,
        source: String,
        message: String,
    },
}

// ── WsBroadcast: tabla process_id → Sender ───────────────────────────────────

#[derive(Clone, Default)]
pub struct WsBroadcast {
    inner: Arc<RwLock<HashMap<Uuid, broadcast::Sender<WsEvent>>>>,
    relay_shutdown: Arc<RwLock<HashMap<Uuid, tokio::sync::oneshot::Sender<()>>>>,
    pg_listeners_active: Arc<RwLock<std::collections::HashSet<Uuid>>>,
    /// CancellationToken por proceso — se cancela cuando no queda ningún cliente WS.
    pg_listener_cancel: Arc<RwLock<HashMap<Uuid, tokio_util::sync::CancellationToken>>>,
    /// Contador de clientes WS activos por proceso.
    client_count: Arc<RwLock<HashMap<Uuid, usize>>>,
}

impl WsBroadcast {
    /// Obtiene o crea un Sender para el proceso. El Sender vive mientras haya
    /// Receivers (clientes WS conectados) o mientras la API no lo limpie.
    pub async fn sender(&self, process_id: Uuid) -> broadcast::Sender<WsEvent> {
        // Fast path: ya existe
        {
            let map = self.inner.read().await;
            if let Some(tx) = map.get(&process_id) {
                return tx.clone();
            }
        }
        // Slow path: crear
        let mut map = self.inner.write().await;
        // Double-check tras upgrade
        if let Some(tx) = map.get(&process_id) {
            return tx.clone();
        }
        let (tx, _) = broadcast::channel(BROADCAST_CAPACITY);
        map.insert(process_id, tx.clone());
        tx
    }

    /// Publica un evento a todos los clientes WS del proceso.
    /// Fire-and-forget — si no hay receptores simplemente se descarta.
    pub async fn publish(&self, process_id: Uuid, event: WsEvent) {
        let map = self.inner.read().await;
        if let Some(tx) = map.get(&process_id) {
            // send() falla si no hay receivers — ignorar
            drop(tx.send(event));
        }
    }

    /// Limpia entradas de procesos sin receptores activos.
    /// Llamar ocasionalmente para evitar acumulación de Senders muertos.
    pub async fn gc(&self) {
        let mut map = self.inner.write().await;
        map.retain(|_, tx| tx.receiver_count() > 0);
    }

    /// Registrar un cliente WS conectado. Arranca los listeners si es el primero.
    pub async fn client_connect(&self, process_id: Uuid, pool: &sqlx::PgPool) {
        let mut counts = self.client_count.write().await;
        let count = counts.entry(process_id).or_insert(0);
        *count += 1;
        let is_first = *count == 1;
        drop(counts);

        if is_first {
            self.ensure_pg_listeners(process_id, pool).await;
        }
    }

    /// Registrar un cliente WS desconectado. Si era el último, cancelar los listeners.
    pub async fn client_disconnect(&self, process_id: Uuid) {
        let mut counts = self.client_count.write().await;
        let count = counts.entry(process_id).or_insert(0);
        if *count > 0 {
            *count -= 1;
        }
        let is_last = *count == 0;
        drop(counts);

        if is_last {
            // Cancelar listeners — libera las 3 conexiones de Postgres
            if let Some(token) = self.pg_listener_cancel.write().await.remove(&process_id) {
                token.cancel();
            }
            // Permitir que se relancen si alguien conecta de nuevo
            self.pg_listeners_active.write().await.remove(&process_id);
            info!("WS: último cliente desconectó de {process_id} — listeners cancelados");
        }
    }

    /// Arrancar los 3 listeners de pg_notify para un proceso una sola vez.
    /// Cada listener consume una conexión del pool permanentemente, así que
    /// los creamos una vez y los reutilizamos para todos los clientes WS.
    pub async fn ensure_pg_listeners(&self, process_id: Uuid, pool: &sqlx::PgPool) {
        {
            let active = self.pg_listeners_active.read().await;
            if active.contains(&process_id) {
                return;
            }
        }
        {
            let mut active = self.pg_listeners_active.write().await;
            if active.contains(&process_id) {
                return;
            }
            active.insert(process_id);
        }

        let cancel = tokio_util::sync::CancellationToken::new();
        self.pg_listener_cancel
            .write()
            .await
            .insert(process_id, cancel.clone());

        let pid_str = process_id.to_string().replace('-', "_");

        macro_rules! spawn_pg_listener {
            ($channel:expr, $ws:expr, $pid:expr, $pool:expr, $cancel:expr, $handler:expr) => {{
                let channel   = $channel;
                let ws        = $ws.clone();
                let pid       = $pid;
                let pool      = $pool.clone();
                let cancel    = $cancel.clone();
                let handler   = std::sync::Arc::new($handler);
                tokio::spawn(async move {
                    use sqlx::postgres::PgListener;
                    loop {
                        if cancel.is_cancelled() { break; }
                        let mut listener = match PgListener::connect_with(&pool).await {
                            Ok(l) => l,
                            Err(e) => {
                                tracing::warn!("pg_listener {channel}: {e} — reintento en 5s");
                                tokio::select! {
                                    _ = cancel.cancelled() => break,
                                    _ = tokio::time::sleep(tokio::time::Duration::from_secs(5)) => {}
                                }
                                continue;
                            }
                        };
                        if listener.listen(&channel).await.is_err() { break; }
                        tracing::info!("WS: escuchando PG NOTIFY {channel}");
                        loop {
                            tokio::select! {
                                _ = cancel.cancelled() => {
                                    tracing::info!("WS: listener {channel} cancelado");
                                    return; // salir del task completo
                                }
                                result = listener.recv() => {
                                    match result {
                                        Ok(notif) => {
                                            if let Ok(val) = serde_json::from_str::<serde_json::Value>(notif.payload()) {
                                                handler(val, ws.clone(), pid).await;
                                            }
                                        }
                                        Err(e) => {
                                            tracing::warn!("pg_listener {channel} error: {e} — reconectando");
                                            break; // reconectar loop exterior
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            }};
        }

        // ── ws_state_: estado del pipeline + process_status ───────────────
        spawn_pg_listener!(
            format!("ws_state_{pid_str}"),
            self,
            process_id,
            pool,
            cancel,
            |val: serde_json::Value, ws: WsBroadcast, pid: Uuid| async move {
                if let Some(status) = val.get("process_status").and_then(|v| v.as_str()) {
                    let error_message = val
                        .get("error_message")
                        .and_then(|v| v.as_str())
                        .map(String::from);
                    ws.publish(
                        pid,
                        WsEvent::ProcessStatus {
                            status: status.to_string(),
                            last_seen_at: None,
                            error_message,
                        },
                    )
                    .await;
                } else if let Some(pipeline_id) = val.get("pipeline_id").and_then(|v| v.as_str()) {
                    let state_val = val.get("state").cloned().unwrap_or_default();
                    ws.publish(
                        pid,
                        WsEvent::PipelineState {
                            pipeline_id: pipeline_id.to_string(),
                            state: state_val,
                        },
                    )
                    .await;
                }
            }
        );

        // ── ws_ack_: etapas de confirmación MQTT ──────────────────────────
        spawn_pg_listener!(
            format!("ws_ack_{pid_str}"),
            self,
            process_id,
            pool,
            cancel,
            |val: serde_json::Value, ws: WsBroadcast, pid: Uuid| async move {
                let actuator_id = val
                    .get("actuator_id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let pipeline_id = val
                    .get("pipeline_id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let msg_str = serde_json::to_string(&val).unwrap_or_default();
                ws.publish(
                    pid,
                    WsEvent::MqttAck {
                        pipeline_id,
                        actuator_id,
                        msg: msg_str,
                    },
                )
                .await;
            }
        );

        // ── ws_log_: logs en tiempo real ──────────────────────────────────
        spawn_pg_listener!(
            format!("ws_log_{pid_str}"),
            self,
            process_id,
            pool,
            cancel,
            |val: serde_json::Value, ws: WsBroadcast, pid: Uuid| async move {
                let level = val
                    .get("level")
                    .and_then(|v| v.as_str())
                    .unwrap_or("info")
                    .to_string();
                let source = val
                    .get("source")
                    .and_then(|v| v.as_str())
                    .unwrap_or("system")
                    .to_string();
                let message = val
                    .get("message")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                ws.publish(
                    pid,
                    WsEvent::Log {
                        level,
                        source,
                        message,
                    },
                )
                .await;
            }
        );
    }

    /// Lanzar el relay MQTT para un proceso si aún no está corriendo.
    pub async fn ensure_mqtt_relay(
        &self,
        process_id: Uuid,
        broker_url: String,
        client_id: String,
        username: Option<String>,
        password: Option<String>,
        ack_topic: String,
    ) {
        let already_running = self.relay_shutdown.read().await.contains_key(&process_id);
        if already_running {
            return;
        }

        let (tx, rx) = tokio::sync::oneshot::channel();
        self.relay_shutdown.write().await.insert(process_id, tx);

        let ws_clone = self.clone();
        tokio::spawn(crate::tasks::mqtt_relay::run(
            process_id, broker_url, client_id, username, password, ack_topic, ws_clone, rx,
        ));
    }

    /// Detener el relay MQTT de un proceso (cuando todos los clientes WS se desconectan).
    pub async fn stop_mqtt_relay(&self, process_id: Uuid) {
        if let Some(tx) = self.relay_shutdown.write().await.remove(&process_id) {
            tx.send(()).ok();
        }
    }
}

// ── Mensaje cliente → servidor ────────────────────────────────────────────────

#[derive(Debug, Deserialize)]
struct ClientMsg {
    #[serde(rename = "type")]
    msg_type: String,
    // El resto de campos se pasan directamente al command handler
    #[serde(flatten)]
    payload: Value,
}

// ── Handler WebSocket ─────────────────────────────────────────────────────────

/// GET /api/v1/processes/:id/ws
///
/// Upgrade a WebSocket. Requiere cookie de sesión válida (verificada con JWT
/// antes del upgrade, igual que el resto de los endpoints de proceso).
pub async fn ws_handler(
    ws: WebSocketUpgrade,
    State(state): State<AppState>,
    Path(process_id): Path<Uuid>,
    // Nota: la auth se verifica ANTES del upgrade para poder devolver 401 HTTP.
    // axum::extract::ws no permite errores HTTP post-upgrade.
    claims: crate::auth::Claims,
) -> impl IntoResponse {
    // Verificar acceso al proceso — incluye owner y colaboradores.
    // Usar get_process_role que hace LEFT JOIN con processes (owner_id)
    // para no excluir al dueño del proceso que no tiene fila en process_collaborators.
    let role: Option<String> = sqlx::query!(
        r#"
        SELECT
            CASE
                WHEN p.owner_id = $2 THEN 'admin'
                WHEN c.role IS NOT NULL THEN c.role
                ELSE NULL
            END AS role
        FROM processes p
        LEFT JOIN process_collaborators c
            ON c.process_id = p.id AND c.user_id = $2
        WHERE p.id = $1
        "#,
        process_id,
        claims.sub,
    )
    .fetch_optional(&state.pool)
    .await
    .ok()
    .flatten()
    .and_then(|r| r.role);

    let role_ok = role
        .as_deref()
        .map(|r| matches!(r, "viewer" | "operator" | "admin"))
        .unwrap_or(false);

    if !role_ok {
        return axum::http::StatusCode::FORBIDDEN.into_response();
    }

    let state_clone = state.clone();
    ws.on_upgrade(move |socket| handle_socket(socket, state_clone, process_id, claims.sub))
        .into_response()
}

async fn handle_socket(socket: WebSocket, state: AppState, process_id: Uuid, user_id: Uuid) {
    let (mut sink, mut stream) = socket.split();

    // Suscribirse al broadcast de este proceso
    let tx = state.ws.sender(process_id).await;
    let mut rx = tx.subscribe();

    info!("WS conectado: proceso={process_id} user={user_id}");

    // Registrar cliente — arranca listeners si es el primero, o reutiliza los existentes.
    // Cuando el último cliente desconecte, client_disconnect cancela los listeners
    // y libera las 3 conexiones de Postgres.
    state.ws.client_connect(process_id, &state.pool).await;

    // ── Lanzar relay MQTT si el proceso tiene broker configurado ──────────
    {
        let cfg_row = sqlx::query!("SELECT config FROM processes WHERE id = $1", process_id)
            .fetch_optional(&state.pool)
            .await;

        if let Ok(Some(row)) = cfg_row {
            let cfg = &row.config;
            let broker_url = cfg
                .pointer("/shared_connections/mqtt/broker_url")
                .and_then(|v| v.as_str())
                .map(str::to_string);

            if let Some(broker_url) = broker_url {
                let username = cfg
                    .pointer("/shared_connections/mqtt/username")
                    .and_then(|v| v.as_str())
                    .map(str::to_string);
                let password = cfg
                    .pointer("/shared_connections/mqtt/password")
                    .and_then(|v| v.as_str())
                    .map(str::to_string);

                let relay_client_id = format!("agrodash-ws-relay-{process_id}");
                let ack_topic =
                    std::env::var("MQTT_ACK_TOPIC").unwrap_or_else(|_| "ack/valvula".to_string());

                info!("WS: lanzando relay MQTT → {broker_url} topic={ack_topic}");
                state
                    .ws
                    .ensure_mqtt_relay(
                        process_id,
                        broker_url,
                        relay_client_id,
                        username,
                        password,
                        ack_topic,
                    )
                    .await;
            } else {
                debug!("WS: proceso sin shared_connections.mqtt — relay no lanzado");
            }
        } else {
            debug!("WS: no se pudo leer config del proceso para relay");
        }
    }

    // Enviar estado inicial del proceso al conectar
    {
        // Pipeline states
        let rows = sqlx::query!(
            "SELECT pipeline_id, state FROM pipeline_states WHERE process_id = $1",
            process_id
        )
        .fetch_all(&state.pool)
        .await;

        if let Ok(rows) = rows {
            for row in rows {
                let evt = WsEvent::PipelineState {
                    pipeline_id: row.pipeline_id,
                    state: row.state,
                };
                if let Ok(json) = serde_json::to_string(&evt) {
                    sink.send(Message::Text(json)).await.ok();
                }
            }
        }

        // Status del proceso
        let status_row = sqlx::query!(
            "SELECT status, last_seen_at FROM processes WHERE id = $1",
            process_id
        )
        .fetch_optional(&state.pool)
        .await;

        if let Ok(Some(row)) = status_row {
            let evt = WsEvent::ProcessStatus {
                status: row.status,
                last_seen_at: row.last_seen_at.map(|t| t.to_rfc3339()),
                error_message: None,
            };
            if let Ok(json) = serde_json::to_string(&evt) {
                sink.send(Message::Text(json)).await.ok();
            }
        }
    }

    // Loop principal: leer del broadcast Y del cliente simultáneamente
    loop {
        tokio::select! {
            // ── Broadcast → cliente ───────────────────────────────────────
            result = rx.recv() => {
                match result {
                    Ok(evt) => {
                        match serde_json::to_string(&evt) {
                            Ok(json) => {
                                if sink.send(Message::Text(json)).await.is_err() {
                                    debug!("WS sink cerrado: proceso={process_id}");
                                    break;
                                }
                            }
                            Err(e) => warn!("WS serialize error: {e}"),
                        }
                    }
                    Err(broadcast::error::RecvError::Lagged(n)) => {
                        warn!("WS cliente lagged {n} mensajes: proceso={process_id}");
                        // Enviar notificación de que se perdieron mensajes
                        let msg = json!({ "type": "error", "message": format!("Se perdieron {n} mensajes por conexión lenta") });
                        sink.send(Message::Text(msg.to_string())).await.ok();
                        // Continuar — no desconectar por lag
                    }
                    Err(broadcast::error::RecvError::Closed) => {
                        // No hay más senders — proceso terminado
                        break;
                    }
                }
            }

            // ── Cliente → API ─────────────────────────────────────────────
            result = stream.next() => {
                match result {
                    Some(Ok(Message::Text(text))) => {
                        handle_client_msg(&state, process_id, user_id, &text, &mut sink).await;
                    }
                    Some(Ok(Message::Ping(data))) => {
                        sink.send(Message::Pong(data)).await.ok();
                    }
                    Some(Ok(Message::Close(_))) | None => {
                        debug!("WS cliente cerró: proceso={process_id}");
                        break;
                    }
                    Some(Err(e)) => {
                        debug!("WS error: {e}");
                        break;
                    }
                    _ => {}
                }
            }
        }
    }

    info!("WS desconectado: proceso={process_id} user={user_id}");

    // Decrementar contador — si era el último cliente, cancela los listeners
    // de pg_notify y libera las 3 conexiones de Postgres.
    state.ws.client_disconnect(process_id).await;

    // Si no quedan clientes WS para este proceso, detener el relay MQTT
    let tx = state.ws.sender(process_id).await;
    if tx.receiver_count() == 0 {
        state.ws.stop_mqtt_relay(process_id).await;
    }
}

/// Procesa un mensaje JSON del cliente.
async fn handle_client_msg(
    state: &AppState,
    process_id: Uuid,
    user_id: Uuid,
    text: &str,
    sink: &mut futures_util::stream::SplitSink<WebSocket, Message>,
) {
    let msg: ClientMsg = match serde_json::from_str(text) {
        Ok(m) => m,
        Err(_) => {
            let err = json!({ "type": "error", "message": "JSON inválido" });
            sink.send(Message::Text(err.to_string())).await.ok();
            return;
        }
    };

    match msg.msg_type.as_str() {
        "ping" => {
            sink.send(Message::Text(json!({ "type": "pong" }).to_string()))
                .await
                .ok();
        }

        "command" => {
            // Verificar que el usuario tiene rol operator/admin para comandos
            let role: String = sqlx::query!(
                r#"
                SELECT
                    CASE
                        WHEN p.owner_id = $2 THEN 'admin'
                        WHEN c.role IS NOT NULL THEN c.role
                        ELSE NULL
                    END AS role
                FROM processes p
                LEFT JOIN process_collaborators c
                    ON c.process_id = p.id AND c.user_id = $2
                WHERE p.id = $1
                "#,
                process_id,
                user_id,
            )
            .fetch_optional(&state.pool)
            .await
            .ok()
            .flatten()
            .and_then(|r| r.role)
            .unwrap_or_default();

            if !matches!(role.as_str(), "operator" | "admin") {
                let err = json!({ "type": "error", "message": "Sin permiso para enviar comandos" });
                sink.send(Message::Text(err.to_string())).await.ok();
                return;
            }

            // Reusar la lógica de send_command: construir el payload completo
            // y llamar al mismo traductor cmd→AgentCommand.
            // Re-usamos la función de traducción de processes.rs exponiéndola como pub(crate).
            let pipeline_id = msg
                .payload
                .get("pipeline_id")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();

            if pipeline_id.is_empty() {
                let err = json!({ "type": "error", "message": "Falta pipeline_id" });
                sink.send(Message::Text(err.to_string())).await.ok();
                return;
            }

            let key = crate::agent_manager::AgentKey {
                process_id,
                pipeline_id,
            };

            // Traducir payload → AgentCommand usando el mismo código que el endpoint REST
            match crate::routes::processes::parse_agent_command(&msg.payload) {
                Ok(agent_cmd) => {
                    // Escribir desired_state en DB igual que send_command HTTP.
                    // Sin esto el agente pierde el override si se reinicia.
                    let cmd_str = msg
                        .payload
                        .get("cmd")
                        .and_then(|v| v.as_str())
                        .unwrap_or("");
                    let act_id = msg
                        .payload
                        .get("actuator_id")
                        .and_then(|v| v.as_str())
                        .unwrap_or("__all__")
                        .to_string();
                    let pid = key.pipeline_id.clone();
                    match cmd_str {
                        "Override" => {
                            let action_str = msg
                                .payload
                                .get("action")
                                .and_then(|v| v.as_str())
                                .unwrap_or("hold");
                            sqlx::query!(
                                r#"INSERT INTO pipeline_states (process_id, pipeline_id, override_action, updated_at)
                                   VALUES ($1, $2, $3, now())
                                   ON CONFLICT (process_id, pipeline_id)
                                   DO UPDATE SET override_action = $3, updated_at = now()"#,
                                process_id, pid,
                                serde_json::json!({ &act_id: action_str }),
                            ).execute(&state.pool).await.ok();
                        }
                        "ClearOverride" | "ClearWatchdog" => {
                            sqlx::query!(
                                r#"INSERT INTO pipeline_states (process_id, pipeline_id, override_action, updated_at)
                                   VALUES ($1, $2, NULL, now())
                                   ON CONFLICT (process_id, pipeline_id)
                                   DO UPDATE SET override_action = NULL, updated_at = now()"#,
                                process_id, pid,
                            ).execute(&state.pool).await.ok();
                        }
                        _ => {}
                    }

                    if let Err(e) = state.manager.notify(&key, agent_cmd).await {
                        let err = json!({ "type": "error", "message": format!("Error enviando comando: {e}") });
                        sink.send(Message::Text(err.to_string())).await.ok();
                    }
                }
                Err(e) => {
                    let err = json!({ "type": "error", "message": e });
                    sink.send(Message::Text(err.to_string())).await.ok();
                }
            }
        }

        "start" | "stop" | "restart" => {
            // Verificar rol operator/admin
            let role: String = sqlx::query!(
                r#"
                SELECT
                    CASE
                        WHEN p.owner_id = $2 THEN 'admin'
                        WHEN c.role IS NOT NULL THEN c.role
                        ELSE NULL
                    END AS role
                FROM processes p
                LEFT JOIN process_collaborators c
                    ON c.process_id = p.id AND c.user_id = $2
                WHERE p.id = $1
                "#,
                process_id,
                user_id,
            )
            .fetch_optional(&state.pool)
            .await
            .ok()
            .flatten()
            .and_then(|r| r.role)
            .unwrap_or_default();

            if !matches!(role.as_str(), "operator" | "admin") {
                let e = json!({ "type": "error", "message": "Sin permiso" });
                sink.send(Message::Text(e.to_string())).await.ok();
                return;
            }

            let row = sqlx::query!(
                "SELECT config, status FROM processes WHERE id = $1",
                process_id
            )
            .fetch_optional(&state.pool)
            .await
            .ok()
            .flatten();

            let Some(row) = row else {
                let e = json!({ "type": "error", "message": "Proceso no encontrado" });
                sink.send(Message::Text(e.to_string())).await.ok();
                return;
            };

            match msg.msg_type.as_str() {
                "start" => {
                    if row.status == "running" {
                        let e = json!({ "type": "error", "message": "Ya está corriendo" });
                        sink.send(Message::Text(e.to_string())).await.ok();
                        return;
                    }
                    let Ok(cfg) =
                        serde_json::from_value::<agrodash_shared::ProcessConfig>(row.config)
                    else {
                        return;
                    };
                    sqlx::query!(
                        "UPDATE processes SET status='running', updated_at=now() WHERE id=$1",
                        process_id
                    )
                    .execute(&state.pool)
                    .await
                    .ok();
                    for pl in &cfg.pipelines {
                        state.manager.spawn(process_id, pl.id.clone()).await;
                    }
                    crate::routes::processes::log_event(
                        &state.pool,
                        process_id,
                        "info",
                        "system",
                        "Proceso iniciado",
                    )
                    .await;
                }

                "stop" => {
                    if row.status == "stopped" {
                        return;
                    }
                    sqlx::query!(
                        "UPDATE processes SET status='stopping', updated_at=now() WHERE id=$1",
                        process_id
                    )
                    .execute(&state.pool)
                    .await
                    .ok();
                    state.manager.stop_process(process_id).await;
                    // Notificar al frontend inmediatamente vía WS
                    state
                        .ws
                        .publish(
                            process_id,
                            WsEvent::ProcessStatus {
                                status: "stopping".to_string(),
                                last_seen_at: None,
                                error_message: None,
                            },
                        )
                        .await;
                    crate::routes::processes::log_event(
                        &state.pool,
                        process_id,
                        "info",
                        "system",
                        "Proceso deteniéndose",
                    )
                    .await;
                }

                "restart" => {
                    if matches!(row.status.as_str(), "running" | "stopping") {
                        let e = json!({ "type": "error", "message": "Detené el proceso antes de reiniciarlo" });
                        sink.send(Message::Text(e.to_string())).await.ok();
                        return;
                    }
                    let Ok(cfg) =
                        serde_json::from_value::<agrodash_shared::ProcessConfig>(row.config)
                    else {
                        return;
                    };
                    state.manager.stop_process(process_id).await;
                    tokio::time::sleep(tokio::time::Duration::from_millis(300)).await;
                    sqlx::query!(
                        "UPDATE processes SET status='running', updated_at=now() WHERE id=$1",
                        process_id
                    )
                    .execute(&state.pool)
                    .await
                    .ok();
                    for pl in &cfg.pipelines {
                        state.manager.spawn(process_id, pl.id.clone()).await;
                    }
                    // Notificar al frontend inmediatamente
                    state
                        .ws
                        .publish(
                            process_id,
                            WsEvent::ProcessStatus {
                                status: "running".to_string(),
                                last_seen_at: None,
                                error_message: None,
                            },
                        )
                        .await;
                    crate::routes::processes::log_event(
                        &state.pool,
                        process_id,
                        "info",
                        "system",
                        "Proceso reiniciado manualmente",
                    )
                    .await;
                }

                _ => {}
            }
        }

        _ => {
            let err = json!({ "type": "error", "message": format!("Tipo de mensaje desconocido: {}", msg.msg_type) });
            sink.send(Message::Text(err.to_string())).await.ok();
        }
    }
}
